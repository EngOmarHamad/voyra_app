import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text("Voyra"),
        backgroundColor: const Color(0xFFD81B60),
      ),
      body: const Center(child: Text("مرحباً بك في تطبيقك الرياضي 💪")),
    );
  }
}
