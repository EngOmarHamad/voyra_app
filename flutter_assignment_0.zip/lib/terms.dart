import 'package:flutter/material.dart';
import 'package:voyra_app/static_pages.dart';

class TermsPage extends StatelessWidget {
  const TermsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return buildModernPage(
      title: "الشروط والأحكام",
      children: const [
        Text("1. الاستخدام", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text("يجب استخدام التطبيق بطريقة قانونية وعدم إساءة استخدام الخدمات."),
        SizedBox(height: 15),

        Text("2. الخصوصية", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text("نحن نحترم خصوصيتك ونحمي بياناتك وفق أعلى المعايير."),

        SizedBox(height: 15),

        Text("3. المسؤولية", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text("التطبيق يقدم محتوى إرشادي ولا يتحمل مسؤولية الاستخدام الخاطئ."),
      ],
    );
  }
}
