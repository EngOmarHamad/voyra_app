import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:voyra_app/main_screen.dart';

void main() {
  runApp(const VoyraApp());
}

class VoyraApp extends StatelessWidget {
  const VoyraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      locale: const Locale('ar'),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('ar'), Locale('en')],
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFD81B60),
        fontFamily: 'Tajawal',
      ),

      /// 🔥 هنا التغيير المهم
      home: const MainScreen(),
    );
  }
}
