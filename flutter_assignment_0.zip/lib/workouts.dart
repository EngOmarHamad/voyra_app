import 'package:flutter/material.dart';

class WorkoutsPage extends StatelessWidget {
  const WorkoutsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = [
      {"name": "تمارين الصدر", "level": "متوسط"},
      {"name": "تمارين الظهر", "level": "مبتدئ"},
      {"name": "تمارين الأرجل", "level": "متقدم"},
      {"name": "تمارين البطن", "level": "مبتدئ"},
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text("التمارين"),
        backgroundColor: const Color(0xFFD81B60),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: workouts.length,
        itemBuilder: (context, index) {
          final w = workouts[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 15),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.fitness_center,
                  size: 30,
                  color: Color(0xFFD81B60),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      w["name"]!,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text("المستوى: ${w["level"]}"),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
