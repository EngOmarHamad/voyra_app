import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(top: 60, bottom: 20),
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Color(0xFFD81B60),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              children: const [
                CircleAvatar(
                  radius: 40,
                  backgroundImage: AssetImage("assets/images/user.png"),
                ),
                SizedBox(height: 10),
                Text(
                  "Omar Hamad",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text("Fitness Lover", style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),

          const SizedBox(height: 20),

          _profileItem(Icons.flag, "الأهداف", "زيادة اللياقة"),
          _profileItem(Icons.monitor_weight, "الوزن", "75 كجم"),
          _profileItem(Icons.height, "الطول", "178 سم"),
          _profileItem(Icons.fitness_center, "مستوى اللياقة", "متوسط"),
        ],
      ),
    );
  }

  Widget _profileItem(IconData icon, String title, String value) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFFD81B60)),
      title: Text(title),
      subtitle: Text(value),
    );
  }
}
