import 'package:flutter/material.dart';
import 'package:voyra_app/about_us.dart';
import 'package:voyra_app/contact_us.dart';
import 'package:voyra_app/privacy.dart';
import 'package:voyra_app/terms.dart';

class StaticPagesScreen extends StatelessWidget {
  const StaticPagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text("الصفحات الثابتة"),
        backgroundColor: const Color(0xFFD81B60),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _menuItem(context, "من نحن", const AboutUsPage()),
          _menuItem(context, "الشروط والأحكام", const TermsPage()),
          _menuItem(context, "سياسة الخصوصية", const PrivacyPage()),
          _menuItem(context, "تواصل معنا", const ContactUsPage()),
        ],
      ),
    );
  }

  Widget _menuItem(BuildContext context, String title, Widget page) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        title: Text(title, textAlign: TextAlign.right),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () =>
            Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }
}

Widget buildModernPage({
  required String title,
  required List<Widget> children,
}) {
  return Scaffold(
    backgroundColor: const Color(0xFFF7F7F7),

    /// ✅ الهيدر فيه العنوان الآن
    appBar: AppBar(
      title: Text(title, style: const TextStyle(color: Colors.black)),
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.white,
      iconTheme: const IconThemeData(color: Colors.black),
    ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),

          /// 🔥 اللوجو
          Center(child: Image.asset('assets/images/logo.png', width: 90)),

          const SizedBox(height: 20),

          const SizedBox(height: 20),

          /// 🔥 كرت المحتوى
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children,
            ),
          ),

          const SizedBox(height: 30),
        ],
      ),
    ),
  );
}
