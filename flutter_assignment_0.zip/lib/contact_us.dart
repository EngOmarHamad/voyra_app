import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:voyra_app/static_pages.dart';

class ContactUsPage extends StatefulWidget {
  const ContactUsPage({super.key});

  @override
  State<ContactUsPage> createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  // حقول الفورم
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController titleController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  // رقم الهاتف وكود الدولة
  final TextEditingController phoneController = TextEditingController();
  String selectedCountryCode = '+970';

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    titleController.dispose();
    messageController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return buildModernPage(
      title: "تواصل معنا",
      children: [
        const Text(
          "يسعدنا تواصلك معنا، يمكنك مراسلتنا مباشرة أو عبر منصات التواصل الاجتماعي",
          textAlign: TextAlign.right,
          style: TextStyle(height: 1.6),
        ),
        const SizedBox(height: 20),

        /// 🔗 أزرار السوشيال
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _socialButton(FontAwesomeIcons.facebookF, const Color(0xFF1877F2)),
            _socialButton(FontAwesomeIcons.xTwitter, Colors.black),
            _socialButton(FontAwesomeIcons.instagram, const Color(0xFFE1306C)),
            _socialButton(FontAwesomeIcons.whatsapp, const Color(0xFF25D366)),
          ],
        ),
        const SizedBox(height: 30),

        /// 🧾 الفورم
        _input("اسم المستخدم", controller: nameController, icon: Icons.person),
        PhoneInputField(
          controller: phoneController,
          initialCountryCode: selectedCountryCode,
          onCountryCodeChanged: (code) {
            setState(() {
              selectedCountryCode = code;
            });
          },
        ),

        _input(
          "البريد الإلكتروني",
          controller: emailController,
          icon: Icons.email,
        ),
        _input("عنوان الرسالة", controller: titleController, icon: Icons.title),
        _input(
          "اكتب رسالتك هنا...",
          controller: messageController,
          maxLines: 4,
          icon: Icons.message,
        ),

        const SizedBox(height: 25),

        /// 🚀 زر الإرسال
        SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed: () {
              String fullPhone = '$selectedCountryCode ${phoneController.text}';
              // هنا يمكن إرسال البيانات أو API call
              print("الاسم: ${nameController.text}");
              print("الهاتف: $fullPhone");
              print("البريد: ${emailController.text}");
              print("العنوان: ${titleController.text}");
              print("الرسالة: ${messageController.text}");
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD81B60),
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: const Text(
              "إرسال الرسالة",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// زر سوشيال ميديا
  Widget _socialButton(IconData icon, Color color) {
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(50),
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Center(child: FaIcon(icon, color: color, size: 22)),
      ),
    );
  }

  /// حقول الإدخال العامة
  Widget _input(
    String hint, {
    int maxLines = 1,
    IconData? icon,
    TextEditingController? controller,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        textAlign: TextAlign.right,
        maxLines: maxLines,
        style: const TextStyle(fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          prefixIcon: icon != null ? Icon(icon, size: 20) : null,
          filled: true,
          fillColor: Colors.white,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 12,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFD81B60), width: 1),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}

class PhoneInputField extends StatefulWidget {
  final TextEditingController controller;
  final String initialCountryCode;
  final ValueChanged<String>? onCountryCodeChanged;

  const PhoneInputField({
    super.key,
    required this.controller,
    this.initialCountryCode = '+970',
    this.onCountryCodeChanged,
  });

  @override
  State<PhoneInputField> createState() => _PhoneInputFieldState();
}

class _PhoneInputFieldState extends State<PhoneInputField> {
  late String selectedCountryCode;
  final FocusNode focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    selectedCountryCode = widget.initialCountryCode;
    focusNode.addListener(() {
      setState(() {}); // لتحديث البوردر عند التركيز
    });
  }

  @override
  void dispose() {
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isFocused = focusNode.hasFocus;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isFocused ? const Color(0xFFD81B60) : Colors.grey.shade300,
            width: 1,
          ),
        ),
        child: Row(
          children: [
            /// 🔹 TextField لباقي الرقم
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 8, right: 4),
                child: TextField(
                  controller: widget.controller,
                  focusNode: focusNode,
                  keyboardType: TextInputType.phone,
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: "رقم الجوال",
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 0,
                      vertical: 12,
                    ),
                    prefixIcon: Icon(Icons.phone, size: 20),
                  ),
                ),
              ),
            ),

            /// 🔹 فاصل رفيع
            Container(height: 20, width: 1, color: Colors.grey.shade300),

            /// 🔹 Dropdown كود الدولة
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
              child: DropdownButton<String>(
                value: selectedCountryCode,
                underline: const SizedBox(),
                items: const [
                  DropdownMenuItem(value: '+970', child: Text('+970')),
                  DropdownMenuItem(value: '+20', child: Text('+20')),
                  DropdownMenuItem(value: '+966', child: Text('+966')),
                  DropdownMenuItem(value: '+971', child: Text('+971')),
                ],
                onChanged: (value) {
                  if (value == null) return;
                  setState(() {
                    selectedCountryCode = value;
                  });
                  if (widget.onCountryCodeChanged != null) {
                    widget.onCountryCodeChanged!(value);
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
