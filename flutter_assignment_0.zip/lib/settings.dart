import 'package:flutter/material.dart';
import 'package:voyra_app/static_pages.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      appBar: AppBar(
        title: const Text("الإعدادات"),
        backgroundColor: const Color(0xFFD81B60),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          /// 🔹 الصفحات الثابتة
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: ListTile(
              leading: const Icon(Icons.description, color: Color(0xFFD81B60)),
              title: const Text("الصفحات الثابتة"),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const StaticPagesScreen()),
                );
              },
            ),
          ),

          /// 🔹 إعدادات أخرى (اختياري)
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: const ListTile(
              leading: Icon(Icons.dark_mode, color: Colors.black54),
              title: Text("الوضع الليلي (قريباً)"),
            ),
          ),

          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: const ListTile(
              leading: Icon(Icons.info, color: Colors.blueGrey),
              title: Text("حول التطبيق"),
            ),
          ),
        ],
      ),
    );
  }
}
